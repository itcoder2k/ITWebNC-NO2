# Medieval Sci-Fi GUI & HUD Kit

Creator: craftpix
License: Standard Indie Commercial License
Format: Standard Engine Package

Included Files:
- Sprites & Textures
- Documentation & Integration Guide
- Commercial License Agreement

Downloaded from GameAsset Marketplace.