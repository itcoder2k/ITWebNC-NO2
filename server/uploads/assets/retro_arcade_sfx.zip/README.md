# Retro 8-Bit Arcade SFX Collection

Creator: kenney_nl
License: CC-BY (Attribution)
Format: Standard Engine Package

Included Files:
- Sprites & Textures
- Documentation & Integration Guide
- Commercial License Agreement

Downloaded from GameAsset Marketplace.